import Data.List
import System.IO
data TextEditor = TE String String String String deriving(Show) --defines data type of TextEditor to contain the strings of left characters, right characters, clipboard characters and highlighted characters as detailed in the ADT

create :: TextEditor
create = (TE "" "" "" "") --creates TextEditor with empty parameters
--destroy :: IO () --destroys TextEditor (W.I.P)
initialise :: TextEditor
initialise = (TE "Is there a heaven for a G" "so many homies in the cemetary shed so many tears" "Clipboard" " remember me ") --initialises TextEditor with sample text

copy :: TextEditor -> TextEditor
copy (TE l r b h) = (TE l r h h) --copies highlighted text to clipboard
paste :: TextEditor -> TextEditor
paste (TE l r b h) = (TE (l++b) r b []) --pastes clipboard at currently selected location
cut :: TextEditor -> TextEditor
cut (TE l r b h) = (TE l r h []) --cuts highlighted text from selection and copies it to clipboard

insertString :: TextEditor -> String -> TextEditor
insertString (TE l r b h) str = (TE (l++str) r b []) --inserts string at currently selected location, works like paste but doesn't involve clipboard

selectLeftWord:: TextEditor -> TextEditor --selects word to left of pointer
selectLeftWord (TE [] r b []) = (TE [] r b []) --does nothing if it can't move left
selectLeftWord (TE l r b h) =
    if [head(reverse(l))] == " " --iterates through function until a space is found, signifying the end of a word
    then (TE l r b h)
    else selectLeftWord(TE (reverse(tail(reverse(l)))) r b ([head(reverse(l))]++h)) --recursively highlights 1 char at a time through the word
selectRightWord:: TextEditor -> TextEditor --selects word to right of pointer
selectRightWord (TE l [] b []) = (TE l [] b []) --does nothing if it can't move right
selectRightWord (TE l r b h) =
    if [head(r)] == " " --iterates through function until a space is found, signifying the end of a word
    then (TE l r b h)
    else selectRightWord(TE l (tail(r)) b (h++[head(r)])) --recursively highlights 1 char at a time through the word
moveLeftWord:: TextEditor -> TextEditor --moves to the word to the left of pointer
moveLeftWord (TE [] r b []) = (TE [] r b []) --does nothing if it can't move left
moveLeftWord (TE l r b h) =
    if [head(reverse(l))] == " " --iterates through function until a space is found, signifying the end of a word
    then (TE l r b h)
    else moveLeftWord(TE (reverse(tail(reverse(l)))) ([head(reverse(l))]++h++r) b []) --recursively moves 1 char at a time through the word
moveRightWord:: TextEditor -> TextEditor --moves to the word to the right of pointer
moveRightWord (TE l [] b []) = (TE l [] b []) --does nothing if it can't move right
moveRightWord (TE l r b h) =
    if [head(r)] == " " --iterates through function until a space is found, signifying the end of a word
    then (TE l r b h)
    else moveRightWord(TE (l++h++[head(r)]) (tail(r)) b []) --recursively moves 1 char at a time through the word

selectLeftChar:: TextEditor -> TextEditor --selects char to left of pointer
selectLeftChar (TE [] r b []) = (TE [] r b []) --selects nothing if it can't move left
selectLeftChar (TE l r b h) = (TE (reverse(tail(reverse(l)))) r b ([head(reverse(l))]++h)) --selects left char
selectRightChar:: TextEditor -> TextEditor --selects char to right of pointer
selectRightChar (TE l [] b []) = (TE l [] b []) --selects nothing if it can't move right
selectRightChar (TE l r b h) = (TE l (tail(r)) b (h++[head(r)])) --selects right char
moveLeftChar:: TextEditor -> TextEditor --moves to the char to the left of pointer
moveLeftChar (TE [] r b []) = (TE [] r b []) --does nothing if it can't move left
moveLeftChar (TE l r b h) = (TE (reverse(tail(reverse(l)))) ([head(reverse(l))]++h++r) b []) --moves 1 char to the left
moveRightChar:: TextEditor -> TextEditor --moves to the char to the right of pointer
moveRightChar (TE l [] b []) = (TE l [] b []) --does nothing if it can't move right
moveRightChar (TE l r b h) = (TE (l++h++[head(r)]) (tail(r)) b []) --moves 1 char to the right

deleteSelection :: TextEditor -> TextEditor --deletes highlighted text
deleteSelection (TE l r b h) = (TE l r b [])

jumpToStart :: TextEditor -> TextEditor --moves to end of string
jumpToStart (TE l r b h) = (TE [] (l++h++r) b [])
jumpToEnd :: TextEditor -> TextEditor --moves to start of string
jumpToEnd (TE l r b h) = (TE (l++h++r) [] b [])

save :: TextEditor -> FilePath -> IO () --saves text to a txt file
save (TE l r b h) sv = do
    let txt = l++h++r --combines all strings into one
    writeFile "text.txt" txt
load :: TextEditor -> FilePath -> IO TextEditor --loads txt file into editor
load (TE l r b h) ld = do
    contents <- readFile ld
    return (TE contents [] [] []) --returns text in file to the left of the pointer

findString :: TextEditor -> String -> IO () --finds if a particular string is in the file
findString (TE l r b h) word =
    if isInfixOf word (l++h++r) --checks if the main string contains the required string
    then putStrLn (word ++ " is in the string")
    else putStrLn (word ++ " is not in the string")