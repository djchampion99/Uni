using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args) //to get the program to work, you must enter either 1 or 2 in the Developer Command Prompt after "boston.exe"
        {
			int p = 0;
			try //only input in the code that could break the code is the input for the number of players, as the number could be too big, or if null could crash the program
			{
				//exception handling. if incorrect value, program stopped
				if((args[0] != "1" && args[0] != "2"))
				{
					Console.WriteLine("Please enter either 1 or 2 after 'boston.exe' in the command prompt.");
					return; //ends program
				}
				
				//p holds the console input and determines the number of players
				p = Convert.ToInt32(args[0]);
				
				//single-player with bot
				if(p == 1) Console.WriteLine("Welcome to single-player.");
				
				//two-player
				else if(p == 2) Console.WriteLine("Welcome to two-player.");
			}
			catch (OverflowException) //if the value is too big, it is caught here
			{
				Console.WriteLine("Exception: Overflow");
				Console.WriteLine("The number you entered was too big, please restart and try again");
				return; //exits program
			}
			catch (IndexOutOfRangeException) //if the value is null or out of the args range, it is caught here
			{
				Console.WriteLine("Exception: Index out of Range");
				Console.WriteLine("Please enter either 1 or 2 after 'boston.exe' in the command prompt.");
				return; //exits program
			}
			
			
			while(true)	//game loops until restarted or quit
			{
				//initializing any potential players
				Player player = new Player(0,0);
				Player computer = new Player(0,0);
				Player player1 = new Player(0,0);
				Player player2 = new Player(0,0);
				
				Console.WriteLine("Which gamemode? Match or score?");
				string gm = "";
				while(true) //loops until valid input recieved
				{
					gm = Console.ReadLine(); //recieves user input
					gm = gm.ToLower(); //converts to lower case for simplicity
					if(gm.Equals("match",StringComparison.Ordinal) || gm.Equals("score",StringComparison.Ordinal)) break; //loop broken if input correct
					else Console.WriteLine("Please type 'match' or 'score'"); //more exception handling. will loop until 'score' or 'match' are chosen
				}
				Game game = new Game(); //instance of game class received
				int rounds = 0;
				Console.WriteLine("\nGAME START------------\n");
				while(true) //rounds loop until broken by a game-winning event
				{
					rounds++; //increments the number of rounds
					int t1 = 0; //initializes player 1 total
					int t2 = 0; //initializes player 2 / computer total
					int outcome = game.Round(p, ref t1, ref t2); //starts a round of the game and recieves the outcome
					Console.WriteLine();
					if(gm == "match") //checks gamemode
					{
						if(outcome == 0) //0 is what the round returns if the scores are tied
						{
							Console.WriteLine("Tied");
						}
						else if(outcome == 1) //1 is what is returned when player 1 wins
						{
							Console.WriteLine("P1 Wins round {0}!",rounds);
							if (p == 1) player.Wins++; //if single player, increases player score
							else player1.Wins++; //if multiplayer, increases player 1 score
						}
						else if(outcome == 2) //2 is what is returned when player 2 wins
						{
							if (p == 1) //checks if single player
							{
								Console.WriteLine("Computer Wins round {0}!",rounds);
								computer.Wins++; //increases computer score
							}
							else //if not single player, must be multiplayer
							{
								Console.WriteLine("P2 Wins round {0}!",rounds);
								player2.Wins++; //increases computer score
							}
						}
					}
					else //if not match it must be score
					{
						Console.WriteLine("Round {0} Scores... {1}:{2}",rounds,t1,t2);
						if (p == 1) //if one player...
							{
								player.Score += t1;
								computer.Score += t2; //scores added to player / computer
							}
						else //if two player...
							{
								player1.Score += t1;
								player2.Score += t2; //scores added to player1 / player2
							}
					}
					
					//determines if the game is over
					if((gm.Equals("score",StringComparison.Ordinal) && rounds == 5) || (gm.Equals("match",StringComparison.Ordinal) &&(player.Wins == 5 || computer.Wins == 5 || player1.Wins == 5 || player2.Wins == 5))) //if 'match' game and one player has reached 5, the game will end. it will also end if 'score' game and 5 rounds have passed
					{
						Console.WriteLine("\nGAME FINISHED\n");
						break; //breaks out of the infinite loop to get to the conclusion of the game
					}
					else Console.WriteLine("\nNEXT ROUND------------\n");
				}
				//win
				string winner = "";
				if(gm.Equals("match",StringComparison.Ordinal)) //checks if 'match' gamemode
				{
					int m1 = 0;
					int m2 = 0;
					
					if(p == 1) //if one player
					{
						m1 = player.Wins;
						m2 = computer.Wins;
						if(player.Wins > computer.Wins) winner = "Player"; //if player wins more than computer, they win overall
						else winner = "Computer"; //otherwise the computer wins
					}
					else //must be 2 player
					{
						m1 = player1.Wins;
						m2 = player2.Wins;
						if(player1.Wins > player2.Wins) winner = "Player 1"; //if player1 wins more than player2, they win overall
						else winner = "Player 2"; //otherwise player 2 wins
					}
					Console.WriteLine("Final scores... {0}:{1}\n\nCongratulations {2}, you are the winner!",m1,m2,winner); //outputs the finals scores and the winner
				}
				else //otherwise must be 'score' gamemode
				{
					int s1 = 0;
					int s2 = 0;
					
					if(p == 1) //if one player
					{
						s1 = player.Score;
						s2 = computer.Score;
						if(player.Score > computer.Score) winner = "Player"; //if player score is higher than computer, they win
						else winner = "Computer"; //otherwise the computer wins
					}
					else //must be 2 player
					{
						s1 = player1.Score;
						s2 = player2.Score;
						if(player1.Score > player2.Score) winner = "Player 1"; //if player1 score is higher than player2, they win
						else winner = "Player 2"; //otherwise player 2 wins
					}
					Console.WriteLine("Final scores... {0}:{1}\n\nCongratulations {2}, you are the winner!",s1,s2,winner); //outputs the finals scores and the winner
				}
				Console.WriteLine("Thank you ever so much for playing. Please type 'R' to restart or 'Q' to quit. To change the number of players, you will have to quit and reload "); //restart or quit by pressing R or Q respectively
				while(true) //repeated until input accepted
				{
					string next = Console.ReadLine(); //recieves input
					if(next.ToLower() == "r") break; //restarts the while(true) loop that the game is encapsulated in
					if(next.ToLower() == "q") return; //ends the program
					else Console.WriteLine("Please type either Q or R "); //prompts the user to press R or Q if they enter neither
				}
			}
        }
    }
	//Dice rolling function
	class Die
    {
        Random r = new Random(); //random function initialized
		public int DiceRoll()
		{
			return r.Next(1,7); //picks random number from 1 to 6, just like on a regular dice
		}
    }
	//Game code
	class Game
    {
        public int Round(int mode, ref int t1, ref int t2) //takes total 1 and 2 by reference to update them without having to return multiple values
		{
			Die d = new Die(); //reference to Die class
			int n = 0; //variable used to hold value of a dice roll
			List<int> rolls1 = new List<int>();
			List<int> rolls2 = new List<int>(); //initializes 2 lists to hold roll values for comparison
			for(int i = 3; i >= 1; i--) //repeated 3 times for each roll of the die
			{
				Console.WriteLine("\nPlayer 1 press any button to roll:\n");
				Console.ReadKey(); //when a button is pressed, the roll is simulated
				Console.WriteLine();
				for(int j = 1; j <= i; j++) //rolls the number of die that are left (counts from 3 down to 1 as the round goes on)
				{
					n = d.DiceRoll(); //gets value from 1 to 6 through diceroll function
					Console.WriteLine("Dice roll {0}: {1}",j,n); //shows diceroll to a) give feedback to the player and b) confirm that each value is random
					rolls1.Add(n); //adds roll to list
				}
				rolls1.Sort(); //sorts player 1's list
				t1 += rolls1[i-1]; //when ordered from low to high, the last value will be the highest. the highest value is added to the total
				Console.WriteLine("Highest roll: {0}",rolls1[i-1]); //logs the highest roll
				rolls1.Clear(); //clears list so it can be re-used in the next roll
				
				if(mode == 2) //checks if 2-player
				{
					Console.WriteLine("\nPlayer 2 press any button to roll:\n");
					Console.ReadKey();
					Console.WriteLine();
					for(int j = 1; j <= i; j++)
					{
						n = d.DiceRoll();
						Console.WriteLine("Dice roll {0}: {1}",j,n); //entire process is pretty much the same as the previous, but affects the 2nd roll list
						rolls2.Add(n);
					}
					rolls2.Sort();
					t2 += rolls2[i-1];
					Console.WriteLine("Highest roll: {0}",rolls2[i-1]);
					rolls2.Clear();
				}
				
				else
				{
					Console.WriteLine("\nComputer turn:\n");
					for(int j = 1; j <= i; j++)
					{
						n = d.DiceRoll();
						Console.WriteLine("Dice roll {0}: {1}",j,n); //again, same code as above but changing different lists
						rolls2.Add(n);
					}
					rolls2.Sort();
					t2 += rolls2[i-1];
					Console.WriteLine("Highest roll: {0}",rolls2[i-1]);
					rolls2.Clear();
				}
			}
			if(t1>t2) return 1; //p1 wins
			else if(t2>t1) return 2; //p2 or computer wins
			else return 0; // tie
		}
    }
	//Player class controls score / wins
	class Player
    {
        public int Score; //player score stored here
		public int Wins; //no of wins stored here
		public Player(int score, int wins) //for initializing objects of this class
		{
			Score = score;
			Wins = wins;
		}
    }
}