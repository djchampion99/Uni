When running this executable in a command prompt, specify whether you want a single or multi player game as the first parameter (i.e. boston.exe 1 for single player).
You can also specify in-game whether you want to play 'match' mode (players win a point each round, the first to 5 wins the game) or 'score' mode (players add up their total after each round, the player with the highest score after 5 rounds wins the game).

Rules:

The concept of Going to Boston is not complicated. It needs three dice. Roll the three dice
and take the highest number from each roll. Each time you roll you lose a die. So the first
roll is going to be with three dice, the second with two, and the third with a single die.
Total up the three dice, the player with the highest value wins that round.