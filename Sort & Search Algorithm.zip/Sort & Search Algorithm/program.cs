using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
			int opCount; //counts operations
			string loc = ""; //used to display the locations of the desired value
			bool done; //used to break out of loops
			string name = @"Files\"; //appended to the filename to help the program find the folder with all files, more tidy than having them together with the program files
			Console.WriteLine("\n=====WELCOME TO MY PROGRAM=====\n\nPlease type the name of the file you wish to use below...\n");
			name += Console.ReadLine(); //receives filename as input
			double[] array; //iniitialises array for sorting / searching
			int len; //initialises length variable
			
			try
			{
				len = Length(name); //calls Length function
				array = new double[len]; //initializes new array for data to be read to
				Read(ref array, name); //reads data from txt to array using Read function
			}
			catch(FileNotFoundException) //deals with files that aren't in the file folder
			{
				Console.WriteLine("\nPlease input a valid filename, or make sure the file is in the 'Files' folder\n\n=====PROGRAM STOPPED=====");
				return; //exits program
			}
			catch(DirectoryNotFoundException) //deals with null or whitespace inputs
			{
				Console.WriteLine("Please input a filename\n\n=====PROGRAM STOPPED=====");
				return; //exits program
			}
			
			opCount = 0; //reset operation counter
			Console.WriteLine("\nEnter 1 for Quick sort, 2 for Bubble sort or 3 for Insertion sort...\n");
			done = false;
			while(done == false) //will repeat until correct input given
			{
				string sort = Console.ReadLine(); //reads input from user
				switch(sort)
				{
					case "1":
						QuickSort(ref array, 0, len - 1, ref opCount); //sorts array using QuickSort function
						done = true; //stops loop from iterating
						break;
					case "2":
						BubbleSort(ref array, len - 1, ref opCount); //sorts array using QuickSort function
						done = true; //stops loop from iterating
						break;
					case "3":
						InsertionSort(ref array, len - 1, ref opCount); //sorts array using QuickSort function
						done = true; //stops loop from iterating
						break;
					default:
						Console.WriteLine("\nPlease enter 1, 2 or 3\n"); //restarts loop if wrong option picked
						break;
				}
			}
			Console.WriteLine("\n{0} operations performed",opCount);
			Console.WriteLine("\n=====SORTING COMPLETE=====\n\nType a for ascending, or d for descending...\n");
			string choice; //initialises choice variable used for ascending or descending search
			while(true)
			{
				choice = Console.ReadLine(); //receives input for order of data
				Console.WriteLine();
				if(choice == "a")
				{
					for(int i = 0; i < len; i++) //outputs data in ascending order
					{
						Console.WriteLine(array[i]);
					}
					break;
				}
				else if(choice == "d")
				{
					for(int i = len - 1; i >= 0; i--) //outputs data in descending order
					{
						Console.WriteLine(array[i]);
					}
					break;
				}
				else Console.WriteLine("Please type 'a' or 'd'\n"); //deals with erraneous input
			}
			
			double val = 0;
			try
			{
				Console.WriteLine("\nPlease enter the value you wish to search for...\n");
				val = Double.Parse(Console.ReadLine()); //receives input
			}
			catch(Exception) //if input isn't a number it is rejected
			{
				Console.WriteLine("\nIncorrect input\n\n=====PROGRAM STOPPED=====");
				return;
			}
			opCount = 0; //resets operation count
			Console.WriteLine("\nEnter 1 for Linear search, or 2 for Binary search...\n");
			done = false; //resets done variable
			while(done == false)
			{
				string sort = Console.ReadLine(); //recieves user input
				switch(sort)
				{
					case "1":
						LinearSearch(val, array, len, ref opCount, ref loc, choice); //performs linear search
						done = true;
						break;
					case "2":
						BinarySearch(val, array, 0, len-1, ref opCount, ref loc, choice); //performs binary search
						done = true;
						break;
					default:
						Console.WriteLine("\nPlease enter 1 or 2\n"); //restarts loop if wrong option picked
						break;
				}
			}
			if(loc != "") Console.WriteLine("\n{0} was found at location(s) {1}in the sorted array",val,loc); //outputs locations of value
			else Console.WriteLine("\nValue not found"); //error message if val not found
			Console.WriteLine("\n{0} operations performed",opCount); //outputs number of operations
        }
		
		static void Read(ref double[] array, string filename)
		{
			var file = File.OpenText(filename); //finds file
			double p = 0; //placeholder variable for the current line being read
			for(int i = 0; i < Length(filename); i++)
			{
				p = Convert.ToDouble(file.ReadLine()); //reads the number from a line of the file
				Console.WriteLine(p);
				array[i] = p; //assigns value in array to the number from the file
			}
		}
		
		static int Length(string filename)
		{
			int count = 0;
			using(var reader = File.OpenText(filename)) //finds file
			{
				while (reader.ReadLine() != null) //until there are no numbers left, the count is incremented
				{
					count++;
				}
			}
			return count; //returns the length of the file
		}
		
		static void QuickSort(ref double[] array, int left, int right, ref int count)
		{
			int a = left; //variable for lowest element in array
			int b = right; //variable for highest element in array
			double temp = 0; //temporary variable to hold data during a swap
			double pivot = array[Convert.ToInt32(Math.Ceiling((left + right) / 2.0))]; //variable for pivot point. recieves middle value from array
			while(a <= b)
			{
				while((array[a] < pivot) && (a < right)) a++;
				while((array[b] > pivot) && (b > left)) b--;
				if(a <= b)
				{
					temp = array[a]; //values swapped
					array[a] = array[b];
					array[b] = temp;
					a++;
					b--;
					count++; //increments operation counter
				}
			}
			if(left < b) QuickSort(ref array, left, b, ref count); //recursion, repeats sort for left side of pivot
			if(right > a) QuickSort(ref array, a, right, ref count); //recursion, repeats sort for right side of pivot
		}
		
		static void BubbleSort(ref double[] array, int length, ref int count)
		{
			double temp = 0; //temporary variable to hold data during a swap
			for(int i = 0; i < length; i++)
			{
				for(int j = 0; j < length - i; j++)
				{
					if(array[j+1] < array[j])
					{
						temp = array[j]; //values swapped
						array[j] = array[j + 1];
						array[j + 1] = temp;
						count++; //increments operation counter
					}
				}
			}
		}
		
		static void InsertionSort(ref double[] array, int length, ref int count)
		{
			int numSorted = 1;
			double temp = 0;
			int i;
			while(numSorted <= length)
			{
				temp = array[numSorted];
				for(i = numSorted; i > 0; i--)
				{
					count++;
					if(temp < array[i-1]) array[i] = array[i-1];
					else break;
				}
				array[i] = temp;
				numSorted++;
			}
		}
		
		static void LinearSearch(double val, double[] array, int length, ref int count, ref string location, string order)
		{
			for(int i = 0; i < length; i++)
			{
				count++; //increments operation counter
				if(count > length)
				{
					FindNearest(array, val, order); //finds nearest value
					return; //breaks out of loop
				}
				if(array[i] == val)
				{
					if(order == "a") location += ((i+1) + " "); //appends location list with location of value
					else location += ((length-i) + " ");
				}
			}
		}
		
		static void BinarySearch(double val, double[] array, int left, int right, ref int count, ref string location, string order)
		{
			count++; //increments operation counter
			if(count > Math.Log(array.Length,2) + 1)
			{
				FindNearest(array, val, order); //finds nearest value
				return; //breaks out of loop
			}
			int mid = (left + right)/2;
			if(val < array[mid]) BinarySearch(val, array, left, mid - 1, ref count, ref location, order); //if the value is smaller than the midpoint, the left side is searched (recursion)
			if(val > array[mid]) BinarySearch(val, array, mid + 1, right, ref count, ref location, order); //if the value is bigger, the right side is searched (recursion)
			if(val == array[mid])
			{
				int i = mid; //lowest element
				try{ while(array[i] == array[i-1]) i--;}
				catch(Exception){} //if array[i-1] doesn't exist it is caught here
				int j = mid; //highest element
				try{ while(array[j] == array[j+1]) j++;}
				catch(Exception){} //if array[i+1] doesn't exist it is caught here
				for(int k = i; k <= j; k++)
				{
					if(order == "a") location += ((k+1) + " "); //appends location list with location of value
					else location += ((array.Length-k) + " ");
				}
			}
		}
		
		static void FindNearest(double[] array, double val, string order)
		{
			double nearest = array[array.Length-1];
			int location = array.Length;
			for(int i = 0; i < array.Length; i++)
			{
				if(Math.Abs(array[i] - val) < Math.Abs(nearest - val))
				{
					nearest = array[i];
					location = i + 1;
				}
			}
			if(order == "d") location = array.Length - location + 1;
			Console.WriteLine("\nThe value you were looking for isn't in the file. The nearest value is {0} at location {1}", nearest, location);
		}
    }
}