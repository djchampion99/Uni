This program can be run by using a command prompt or simply opening the program.exe file.
The functionality of the program is to sort and search a text file of numbers using various methods.

Any file placed in the 'Files' folder can be accessed by the program (i.e. entering "Change_256.txt" when prompted will search and sort the contents of that file).