This site was created for an assignment in which I was tasked with designing a website for a music artist.
I chose death grips because their aesthetic was fun to work with.

The site features links to their music videos, their 2 free albums and a shirt customisation tool. The website
utilises html, css and javascript.