-- SQL DDL SCRIPTING FOR 1.1

-- DATABASE INITIALISATION
CREATE DATABASE IF NOT EXISTS lcs;

USE lcs;

-- TABLES CREATED
CREATE TABLE IF NOT EXISTS Customer
(
	C_Email varchar(255) NOT NULL,
	DOB date,
	First_Name varchar(255),
	Last_Name varchar(255) NOT NULL,
	House_Number int,
	Street varchar(255),
	City varchar(255),
	Postcode varchar(255) NOT NULL,
	Delivery boolean NOT NULL,
	
	PRIMARY KEY (C_Email)
);

CREATE TABLE IF NOT EXISTS Services
(
    Service_Name varchar(255) NOT NULL,
	Parts_Required varchar(255),
	Service_Price float(9) NOT NULL,
	Service_Length float(9),
	
	PRIMARY KEY (Service_Name)
);

CREATE TABLE IF NOT EXISTS Employee
(
	E_Email varchar(255) NOT NULL,
	National_Insurance varchar(255) NOT NULL UNIQUE,
	First_Name varchar(255),
	Last_Name varchar(255) NOT NULL,
	Training varchar(255),
	DOB date,
	
	PRIMARY KEY (E_Email)
);

CREATE TABLE IF NOT EXISTS Stock
(
	Serial_Number varchar(255) NOT NULL,
	Item_Name varchar(255),
	Price float(9) NOT NULL,
	Stock_Quantity int,
	Suppliers varchar(255),
	
	PRIMARY KEY (Serial_Number)
);

CREATE TABLE IF NOT EXISTS Supplier
(
    S_Email varchar(255) NOT NULL,
	Supplier_Name varchar(255) NOT NULL UNIQUE,
	
	PRIMARY KEY (S_Email)
);

CREATE TABLE IF NOT EXISTS Customer_Order
(
    C_Order_No int NOT NULL AUTO_INCREMENT,
	Discount float(9),
	Total_Price float(9) NOT NULL,
	Order_Date date,
	Order_Time time,
	Order_Status varchar(255),
	C_Email_FK varchar(255) NOT NULL,
	
	PRIMARY KEY (C_Order_No)
);

CREATE TABLE IF NOT EXISTS Purchase_Order
(
    P_Order_No int NOT NULL AUTO_INCREMENT,
	Total_Cost float(9) NOT NULL,
	Order_Status varchar(255),
	Order_Date date,
	Order_Time time,
	Stock_Serial_Number_FK varchar(255) NOT NULL,
	Stock_Quantity int,
	E_Email_FK varchar(255) NOT NULL,
	S_Email_FK varchar(255) NOT NULL,
	
	PRIMARY KEY (P_Order_No)
);

-- ALTER STATEMENTS USED TO ADD FOREIGN KEYS
ALTER TABLE Customer_Order
ADD FOREIGN KEY (C_Email_FK) REFERENCES Customer(C_Email);

ALTER TABLE Purchase_Order
ADD FOREIGN KEY (Stock_Serial_Number_FK) REFERENCES Stock(Serial_Number),
ADD	FOREIGN KEY (E_Email_FK) REFERENCES Employee(E_Email),
ADD	FOREIGN KEY (S_Email_FK) REFERENCES Supplier(S_Email),
ADD Payment_Date date,
ADD Delivery_Date date;

-- SQL DML STATEMENTS FOR 1.2

-- SET DEFAULT VALUES (i)
ALTER TABLE Customer_Order MODIFY COLUMN Order_Status VARCHAR(255) DEFAULT 'Processing';
ALTER TABLE Purchase_Order MODIFY COLUMN Order_Status VARCHAR(255) DEFAULT 'Processing';

-- INSERT DATA INTO DATABASE TABLES (i)
INSERT INTO Customer(C_Email, DOB, First_Name, Last_Name, House_Number, Street, City, Postcode, Delivery)
VALUES('mangumj@gmail.com', STR_TO_DATE('24-10-1970', '%d-%m-%Y'), 'Jeff', 'Mangum', 21, 'Naomi Lane', 'Lincoln', 'LN5 8OC', TRUE),('elverump@gmail.com', STR_TO_DATE('23-5-1978', '%d-%m-%Y'), 'Phil', 'Elverum', 42, 'Crow Drive', 'Lincoln', 'LN5 GP2', FALSE),('curtisi@gmail.com', STR_TO_DATE('15-7-1956', '%d-%m-%Y'), 'Ian', 'Curtis', 80, 'Deborah Grove', 'Lincoln', 'LN6 2JD', TRUE);

INSERT INTO Services(Service_Name, Parts_Required, Service_Price, Service_Length)
VALUES('Deep Clean','N/A',24.50,0.5),('Replace Fan','Computer Fan',42.20,1),('Replace Graphics Card','Graphics Card',68.40,1.5),('Reinstall Windows','N/A',30.0,2);

INSERT INTO Employee(E_Email, National_Insurance, First_Name, Last_Name, Training, DOB)
VALUES('carrm@gmail.com','MC123456C','Mark','Carr','Standard',STR_TO_DATE('10-11-1992', '%d-%m-%Y')),('shodeinder@gmail.com','RS123456S','Ridhwan','Shodeinde','Standard',STR_TO_DATE('20-11-1994', '%d-%m-%Y'));

INSERT INTO Stock(Serial_Number, Item_Name, Price,Stock_Quantity, Suppliers)
VALUES('4CE0460D0G', 'Fan', 10.50, 4, 'Probably Rational Ltd'),('3GD0720D0J', 'Graphics Card', 30.0, 5, 'Brown Jacket Bats Ltd');

INSERT INTO Supplier(S_Email, Supplier_Name)
VALUES('zach@probablyrational.com','Probably Rational Ltd'),('dan@techplay.fun','Techplay Ltd'),('zak@brownjacketbats.co.uk','Brown Jacket Bats Ltd');

INSERT INTO Customer_Order(Discount, Total_Price, Order_Date, Order_Time, C_Email_FK)
VALUES(10, 24.50, STR_TO_DATE('07-01-2019', '%d-%m-%Y'), '13:30','mangumj@gmail.com');

INSERT INTO Purchase_Order(Total_Cost, Payment_Date, Order_Date, Delivery_Date, Order_Time, Stock_Serial_Number_FK, Stock_Quantity, E_Email_FK, S_Email_FK)
VALUES(10.50, STR_TO_DATE('05-01-2019', '%d-%m-%Y'), STR_TO_DATE('05-01-2019', '%d-%m-%Y'), STR_TO_DATE('10-01-2019', '%d-%m-%Y'), '16:20', '4CE0460D0G', 7, 'shodeinder@gmail.com', 'zach@probablyrational.com');

-- DELETING / UPDATING EXISTING RECORDS (i)
DELETE FROM Supplier WHERE S_Email = 'dan@techplay.fun';
UPDATE Employee SET E_Email = 'daviest@gmail.com', First_Name = 'Tom', Last_Name = 'Davies' WHERE First_Name = 'Mark';

-- JOIN STATEMENTS (ii)

-- INNER JOIN USED TO SHOW ALL CUSTOMERS THAT PLACED AN ORDER WITH LCS
SELECT Customer_Order.C_Order_No, Customer.First_Name, Customer.Last_Name
FROM Customer_Order
INNER JOIN Customer ON Customer_Order.C_Email_FK = Customer.C_Email;

-- LEFT JOIN USED TO SHOW ALL EMPLOYEES THAT PLACED A PURCHASE ORDER
SELECT Employee.First_Name, Employee.Last_Name, Purchase_Order.P_Order_No
FROM Purchase_Order
LEFT JOIN Employee ON Employee.E_Email = Purchase_Order.E_Email_FK
ORDER BY Employee.Last_Name;

-- RIGHT JOIN USED TO SHOW ALL STOCK THAT HAS BEEN REQUESTED WITH A PURCHASE ORDER
SELECT Purchase_Order.P_Order_No, Stock.Item_Name
FROM Stock
RIGHT JOIN Purchase_Order ON Purchase_Order.Stock_Serial_Number_FK = Stock.Serial_Number;

-- UNION STATEMENT (iii)

-- UNION USED TO OUTPUT ALL SURNAMES FROM TWO TABLES
(SELECT Last_Name FROM Customer) UNION (SELECT Last_Name FROM Employee);

-- COPY ALL TABLES IN DATABASE (iv)
CREATE TABLE IF NOT EXISTS Copy_Of_Customer LIKE Customer; INSERT INTO Copy_Of_Customer SELECT * FROM Customer;
CREATE TABLE IF NOT EXISTS Copy_Of_Services LIKE Services; INSERT INTO Copy_Of_Services SELECT * FROM Services;
CREATE TABLE IF NOT EXISTS Copy_Of_Employee LIKE Employee; INSERT INTO Copy_Of_Employee SELECT * FROM Employee;
CREATE TABLE IF NOT EXISTS Copy_Of_Stock LIKE Stock; INSERT INTO Copy_Of_Stock SELECT * FROM Stock;
CREATE TABLE IF NOT EXISTS Copy_Of_Supplier LIKE Supplier; INSERT INTO Copy_Of_Supplier SELECT * FROM Supplier;
CREATE TABLE IF NOT EXISTS Copy_Of_Customer_Order LIKE Customer_Order; INSERT INTO Copy_Of_Customer_Order SELECT * FROM Customer_Order;
CREATE TABLE IF NOT EXISTS Copy_Of_Purchase_Order LIKE Purchase_Order; INSERT INTO Copy_Of_Purchase_Order SELECT * FROM Purchase_Order;

-- CREATE USER WITH PERMISSIONS (v)
CREATE USER IF NOT EXISTS 'uol' IDENTIFIED BY 'password';
GRANT SELECT ON * TO 'uol';
-- REVOKE DROP ON * FROM 'uol';
-- REVOKE DELETE ON * FROM 'uol'; CAUSED ERRORS AND PERMISSION NOT GIVEN BY DEFAULT ANYWAY