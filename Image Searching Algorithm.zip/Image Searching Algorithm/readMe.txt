This algorithm searches a larger image for a source image located in it. For example, if a Where's Wally
page was scanned in and an image of Wally was provided, the algorithm would attempt to find Wally
and outline his rough position.

Replace the Wally_grey file with any reference image (as an series of numbers representing the greyscale values),
and the Cluttered_scene file with any image that contains the reference image.