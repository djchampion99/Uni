#pragma once
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Base_Image { //interface class to base the large and reference images on
public:
	virtual void read() = 0;
	virtual void write() = 0;
private:
};

class Large_Image : public Base_Image { //class for holding the cluttered scene
public:
	int r;
	int c;
	double* image;
	vector<vector<double>> matrix;
	Large_Image();
	void read();
	void write();
	~Large_Image();
private:
	string name = "Cluttered_scene.txt";
	char* file = (char*)name.c_str();
	string imgName = "Cluttered_scene.pgm";
	char* img = (char*)imgName.c_str();
};

class Ref_Image : public Base_Image { //class for holding the wally reference
public:
	int r;
	int c;
	double* image;
	vector<vector<double>> matrix;
	Ref_Image();
	void read();
	void write();
	~Ref_Image();
private:
	string name = "Wally_grey.txt";
	char* file = (char*)name.c_str();
	string imgName = "Wally_grey.pgm";
	char* img = (char*)imgName.c_str();
};