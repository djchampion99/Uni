#include "ReadWrite.h"
#include "Main.h"
#include "Images.h"
#include "Matrix.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <map>
#include <exception>

using namespace std;

void doubleToMatrix(int rows, int columns, vector<vector<double>> &matrix, double *data) //converts 1D array of doubles to 2D vector
{
	for (int i = 0; i < rows; i++)
	{
		//cout << i << "-------" << endl;
		for (int j = 0; j < columns; j++)
		{
			matrix[i][j] = data[j + columns * i]; //fills main vector with data
			//cout << matrix[i][j] << endl;
		}
	}
}

double* matrixToDouble(int rows, int columns, vector<vector<double>> &matrix) //converts 1D array of doubles to 2D vector
{
	double* data = new double[rows * columns];
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			data[i * columns + j] = matrix[i][j];
		}
	}
	return data;
}

double evaluateMatrix(int rows, int columns, vector<vector<double>> &matrix, vector<vector<double>> &matrixR) //compares two matrices and finds the sum of squared differences
{
	double squareSum = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			if (matrixR[i][j] != 255) squareSum += pow((matrix[i][j] - matrixR[i][j]),2); //adds square of differences to the sum of squared differences. removes whitespace for simplicity
		}
	}
	return squareSum;
}

void nearestNeighbour(int rowsR, int columnsR, int rowsL, int columnsL, map<int, pair<int, int>> &nList, vector<vector<double>> &matrixR, vector<vector<double>> &matrixL) //populates the nList map to find the most similar location to the wally image
{
	for (int i = 0; i < (rowsL - rowsR); i++) { //iterates through each value for rows in cluttered scene
		for (int j = 0; j < (columnsL - columnsR); j++) { //iterates through each value for columns in cluttered scene
			vector<vector<double>> temp; //initialises temporary matrix for comparison
			temp.resize(rowsR, vector<double>(columnsR, 0));
			int n = 0; //squareSum
			for (int k = 0; k < (rowsR); k++) { //for each row in the reference matrix
				for (int l = 0; l < (columnsR); l++) { //for each column in the reference matrix
					temp[k][l] = matrixL[i + k][j + l]; //temp is filled with the data in the current part of the cluttered scene
				}
			}
			n = evaluateMatrix(rowsR, columnsR, temp, matrixR); //finds sum of squared differences
			std::pair <int, int> pair(i, j); //stores co-ordinates of current part of the cluttered scene
			nList[n] = pair; //assigns sum of squared differences and top left value of the search area to a map
		}
	}
}

void highLight(vector<vector<double>> &clutteredScene, int x, int y, int r, int c) //draws rectangle over wally location
{
	int i = 0;
	for (i; i < c; i++) //left
	{
		clutteredScene[x][y + i] = 0;
	}
	i = 0;
	for (i; i < c; i++) //right
	{
		clutteredScene[x + r][y + i] = 0;
	}
	i = 0;
	for (i; i < r; i++) //top
	{
		clutteredScene[x + i][y] = 0;
	}
	i = 0;
	for (i; i < r; i++) //bottom
	{
		clutteredScene[x + i][y + c] = 0;
	}
}

int main()
{
	std::cout << "Starting!\n";

	Ref_Image *Wally = new Ref_Image();
	Large_Image *Scene = new Large_Image();
	Matrix *WallyMatrix = new Matrix();
	Matrix *SceneMatrix = new Matrix();

	Wally->read();
	Scene->read();
	WallyMatrix->r = Wally->r;
	WallyMatrix->c = Wally->c;
	WallyMatrix->matrix = Wally->matrix;
	SceneMatrix->r = Scene->r;
	SceneMatrix->c = Scene->c;
	SceneMatrix->matrix = Scene->matrix;
	map<int, pair<int, int>> nList;
	nearestNeighbour(WallyMatrix->r, WallyMatrix->c, SceneMatrix->r, SceneMatrix->c, nList, WallyMatrix->matrix, SceneMatrix->matrix);
	
	int x = get<0>(nList.begin()->second);
	int y = get<1>(nList.begin()->second);
	cout << "Ref image is found at " << x << "," << y << endl;
	/*for (auto it = nList.cbegin(); it != nList.cend(); ++it)
	{
		std::cout << it->fiSceneMatrix->rt << " " << it->second.fiSceneMatrix->rt << " " << it->second.second << "\n"; //outputs all map elements
	}*/
	highLight(SceneMatrix->matrix, x, y, WallyMatrix->r, WallyMatrix->c);
	Scene->image = matrixToDouble(SceneMatrix->r, SceneMatrix->c, SceneMatrix->matrix);
	Scene->write();

	delete SceneMatrix;
	delete WallyMatrix;
	delete Scene;
	delete Wally;
	std::cout << "End! Enter anything to quit.\n";
	std::cin.get();
}