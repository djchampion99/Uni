#include "ReadWrite.h"
#include "Main.h"
#include "Images.h"
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

Ref_Image::Ref_Image() { std::cout << "Reference Image Constructor Called\n"; r = 49; c = 36;}
void Ref_Image::read()
{
	image = read_text(file, r, c); //reads data from wally text file into 1D array
	matrix.resize(r, vector<double>(c, 0));
	doubleToMatrix(r, c, matrix, image); //reads 1D array into 2D vector
}
void Ref_Image::write()
{
	write_pgm(img, image, r, c, 255); //writes 1D array to .pgm file
}
Ref_Image::~Ref_Image() { std::cout << "Reference Image Destructor Called\n"; }

Large_Image::Large_Image() { std::cout << "Large Image Constructor Called\n"; r = 768; c = 1024;}
void Large_Image::read()
{
	image = read_text(file, r, c); //reads data from wally text file into 1D array
	matrix.resize(r, vector<double>(c, 0));
	doubleToMatrix(r, c, matrix, image); //reads 1D array into 2D vector
}
void Large_Image::write()
{
	write_pgm(img, image, r, c, 255); //writes 1D array to .pgm file
}
Large_Image::~Large_Image() { std::cout << "Large Image Destructor Called\n"; }