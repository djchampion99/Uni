#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <map>

using namespace std;

void doubleToMatrix(int rows, int columns, vector<vector<double>> &matrix, double *data);
double* matrixToDouble(int rows, int columns, vector<vector<double>> &matrix);
double evaluateMatrix(int rows, int columns, vector<vector<double>> &matrix, vector<vector<double>> &matrixR);
void nearestNeighbour(int rowsR, int columnsR, int rowsL, int columnsL, map<int, pair<int, int>> &nList, vector<vector<double>> &matrixR, vector<vector<double>> &matrixL);
void highLight(vector<vector<double>> &clutteredScene, int x, int y, int r, int c);