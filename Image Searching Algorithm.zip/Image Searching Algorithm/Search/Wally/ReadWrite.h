#pragma once
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

double* read_text(char *fileName, int sizeR, int sizeC);
void write_pgm(char *filename, double *data, int sizeR, int sizeC, int Q);