#pragma once
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Matrix { //interface class to base the large and reference images on
public:
	Matrix();
	vector<vector<double>> matrix;
	int r;
	int c;
	~Matrix();
private:
};