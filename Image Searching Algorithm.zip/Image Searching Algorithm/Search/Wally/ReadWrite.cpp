#include "ReadWrite.h"
#include "Main.h"
#include "Images.h"
#include <iostream>
#include <fstream>

using namespace std;

double* read_text(char *fileName, int sizeR, int sizeC) //reads .txt file into 1D double array. code provided by the module
{
	double* data = new double[sizeR*sizeC];
	int i = 0;
	ifstream myfile(fileName);
	if (myfile.is_open())
	{
		while (myfile.good())
		{
			if (i > sizeR*sizeC - 1) break;
			myfile >> *(data + i);
			//cout << *(data+i) << ' ';
			i++;
		}
		myfile.close();
	}

	else cout << "Unable to open file";
	//cout << i;

	return data;
}

void write_pgm(char *filename, double *data, int sizeR, int sizeC, int Q) //reads 1D double array into .pgm image. code provided by the module
{
	int i;
	unsigned char *image;
	ofstream myfile;

	image = (unsigned char *) new unsigned char[sizeR*sizeC];

	for (i = 0; i < sizeR*sizeC; i++) image[i] = (unsigned char)data[i];

	myfile.open(filename, ios::out | ios::binary | ios::trunc);

	if (!myfile)
	{
		cout << "Can't open file: " << filename << endl;
		exit(1);
	}

	myfile << "P5" << endl;
	myfile << sizeC << " " << sizeR << endl;
	myfile << Q << endl;

	myfile.write(reinterpret_cast<char *>(image), (sizeR*sizeC) * sizeof(unsigned char));

	if (myfile.fail())
	{
		cout << "Can't write image " << filename << endl;
		exit(0);
	}

	myfile.close();

	delete[] image;
}