This code will deploy a cloud network with subnetworks in multiple continents.
All resources are deployed from the yaml file when run in Google Cloud Platform.