This game was created as part of a 5-person team, where I was the lead programmer,
and one of the few with experience using Unity. The goal was to make a game that taught people how
to produce simple code, and this is done by converting basic commands into C# in an attempt to break down
the barrier between a player's inputs and the response onscreen.