This project takes a pgm or ppm image as input and increases the
intensity. You have the option to process it locally or globally,
and the runtimes are output in the console. Note how local
computation takes less time than global computation.