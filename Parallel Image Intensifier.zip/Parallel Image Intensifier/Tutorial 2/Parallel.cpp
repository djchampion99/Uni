///////Parallel Programming - Assessment Item 1 - Daniel Champion 16627962///////

/*

///REPORT///

This program increases the contrast of a given image. When prompted please enter the filename, precision and whether you want local or global processing
into the console. Each kernel's output will be printed along with its runtime, and finally the output image. Press escape when finished to close the
images. The histogram kernel finds the colour value of every pixel of the input image and atomically increments the corresponding bin of a histogram.
The cumulative histogram kernel atomically adds every smaller value of each bin (again in parallel). The look-up table kernel ensures that 255 is the
maximum value by multiplying every bin of the hisogram by 255 / the total size simultaneously. The re-projection kernel runs each pixel of the input
image through the look-up table at the same time. The general profiling of the process is also printed. Each kernel applies a map pattern, performing
a simple operation on each element simultaneously. In some cases barriers are implemented to synchronise the parallel processes and ensure the
program doesn't move on until all operations are complete.

/////IMPORTANT: Please paste any images you wish to use into the "Tutorial 2" folder/////

*/

#include <iostream>
#include <vector>

#include "Utils.h"
#include "CImg.h"

using namespace cimg_library;

void print_help() {
	std::cerr << "Application usage:" << std::endl;

	std::cerr << "  -p : select platform " << std::endl;
	std::cerr << "  -d : select device" << std::endl;
	std::cerr << "  -l : list all platforms and devices" << std::endl;
	std::cerr << "  -f : input image file (default: test.pgm)" << std::endl;
	std::cerr << "  -h : print this message" << std::endl;
}

int main(int argc, char **argv) {
	
	string image_filename; //file to be processed
	int precision; //sets number of colour options per pixel. 256 for 8-bit, 65535 for 16-bit (16-bit may be temperamental, just stick to 8-bit for now)
	bool local;
	
	try {
		cout << "Please enter the image filename (test.pgm by default, .ppm colour image files also work. Any size works): "; //user enters the image to be tested
		cin >> image_filename;
		cout << "Please enter an integer value for image precision (256 for 8-bit): "; //user enters the precision of the image
		cin >> precision;
		cout << "Would you like the computation to be done globally or locally? (0 for global, 1 for local): "; //user enters the precision of the image
		cin >> local;
	}
	
	catch (const cl::Error & err) {
		std::cerr << "ERROR: " << err.what() << ", " << getErrorString(err.err()) << std::endl;
	}

	int platform_id = 0;
	int device_id = 0;
	vector<int> H(precision, 0); //hist bins initialised to 0 
	vector<int> C(precision, 0); //hist bins initialised to 0
	vector<int> L(precision, 0); //hist bins initialised to 0 
	size_t size = H.size() * sizeof(int); // size in bytes of all integers held in histogram
	size_t intSize = sizeof(int); // size in bytes of single integer
	int executionTime = 0; //time taken to execute kernels
	int currentExecution = 0;

	//handles command line options
	for (int i = 1; i < argc; i++) {
		if ((strcmp(argv[i], "-p") == 0) && (i < (argc - 1))) { platform_id = atoi(argv[++i]); }
		else if ((strcmp(argv[i], "-d") == 0) && (i < (argc - 1))) { device_id = atoi(argv[++i]); }
		else if (strcmp(argv[i], "-l") == 0) { std::cout << ListPlatformsDevices() << std::endl; }
		else if ((strcmp(argv[i], "-f") == 0) && (i < (argc - 1))) { image_filename = argv[++i]; }
		else if (strcmp(argv[i], "-h") == 0) { print_help(); return 0; }
	}

	cimg::exception_mode(0);

	//detect any potential exceptions
	try {		
		CImg<unsigned char> image_input(image_filename.c_str());
		CImgDisplay disp_input(image_input,"input");

		//host operations
		//Select computing devices
		cl::Context context = GetContext(platform_id, device_id);

		//display the selected device
		std::cout << "Running on " << GetPlatformName(platform_id) << ", " << GetDeviceName(platform_id, device_id) << std::endl; //outputs the platform and device the code is running on

		//create a queue to which we will push commands for the device
		cl::CommandQueue queue(context, CL_QUEUE_PROFILING_ENABLE);
		cl::Event prof_event;

		//Load & build the device code
		cl::Program::Sources sources;

		AddSources(sources, "kernels/my_kernels.cl");

		cl::Program program(context, sources);

		//build and debug the kernel code
		try { 
			program.build();
		}
		catch (const cl::Error& err) {
			std::cout << "Build Status: " << program.getBuildInfo<CL_PROGRAM_BUILD_STATUS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Options:\t" << program.getBuildInfo<CL_PROGRAM_BUILD_OPTIONS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Log:\t " << program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			throw err;
		}

		//device operations

		//device - buffers
		cl::Buffer dev_image_input(context, CL_MEM_READ_ONLY, image_input.size()); //input image
		cl::Buffer histogram(context, CL_MEM_READ_WRITE, size); //a histogram with a bin for each colour value
		cl::Buffer cumulative_histogram(context, CL_MEM_READ_WRITE, size); //a cumulative histogram with the same parameters
		cl::Buffer look_up_table(context, CL_MEM_READ_WRITE, size); //a look up table, see above
		cl::Buffer dev_image_output(context, CL_MEM_READ_WRITE, image_input.size()); //should be the same as input image

		//HISTOGRAM

		queue.enqueueWriteBuffer(dev_image_input, CL_TRUE, 0, image_input.size(), &image_input.data()[0]);
		queue.enqueueWriteBuffer(histogram, CL_TRUE, 0, size, &H.data()[0]);

		cl::Kernel kernel1;

		if (local == true) {
			kernel1 = cl::Kernel(program, "histogram"); //this takes the input image, and for each pixel increments the bin matching the greyscale value by 1
			kernel1.setArg(0, dev_image_input);
			kernel1.setArg(1, histogram);
			kernel1.setArg(2, cl::Local(size)); //local histogram
			kernel1.setArg(3, precision);
		}
		else {
			kernel1 = cl::Kernel(program, "histogram_global"); //this takes the input image, and for each pixel increments the bin matching the greyscale value by 1
			kernel1.setArg(0, dev_image_input);
			kernel1.setArg(1, histogram);
			kernel1.setArg(2, precision);
		}
		
		queue.enqueueNDRangeKernel(kernel1, cl::NullRange, cl::NDRange(image_input.size()), cl::NullRange, NULL, &prof_event);

		queue.enqueueReadBuffer(histogram, CL_TRUE, 0, size, &H.data()[0]);

		std::cout << "\nHistogram:\n" << H << std::endl;

		currentExecution = prof_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - prof_event.getProfilingInfo<CL_PROFILING_COMMAND_START>(); //outputs execution time
		std::cout << "\nKernel execution time: \n" << currentExecution << std::endl;
		executionTime += currentExecution;
		
		//CUMULATIVE HISTOGRAM

		queue.enqueueWriteBuffer(cumulative_histogram, CL_TRUE, 0, size, &C.data()[0]);

		cl::Kernel kernel2;

		if (local == true) {
			kernel2 = cl::Kernel(program, "cumulative_histogram"); //takes histogram and makes it cumulative, adding the value of all smaller bins to each bin
			kernel2.setArg(0, histogram);
			kernel2.setArg(1, cumulative_histogram);
			kernel2.setArg(2, cl::Local(size)); //local histogram
			kernel2.setArg(3, precision);
		}
		else {
			kernel2 = cl::Kernel(program, "cumulative_histogram_global"); //takes histogram and makes it cumulative, adding the value of all smaller bins to each bin
			kernel2.setArg(0, histogram);
			kernel2.setArg(1, cumulative_histogram);
			kernel2.setArg(2, precision);
		}

		queue.enqueueNDRangeKernel(kernel2, cl::NullRange, cl::NDRange(size), cl::NullRange, NULL, &prof_event);

		queue.enqueueReadBuffer(cumulative_histogram, CL_TRUE, 0, size, &C.data()[0]);

		std::cout << "\nCumulative Histogram:\n" << C << std::endl;

		currentExecution = prof_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - prof_event.getProfilingInfo<CL_PROFILING_COMMAND_START>(); //outputs execution time
		std::cout << "\nKernel execution time: \n" << currentExecution << std::endl;
		executionTime += currentExecution;
		
		//LOOK UP TABLE

		queue.enqueueWriteBuffer(look_up_table, CL_TRUE, 0, L.size(), &L.data()[0]);

		cl::Kernel kernel3;

		if (local == true) {
			kernel3 = cl::Kernel(program, "lut_scaling"); //reduces the cumulative histogram by dividing by the largest value and multiplying by the precision
			kernel3.setArg(0, cumulative_histogram);
			kernel3.setArg(1, look_up_table);
			kernel3.setArg(2, cl::Local(size)); //local histogram
			kernel3.setArg(3, precision);
		}
		else {
			kernel3 = cl::Kernel(program, "lut_scaling_global"); //reduces the cumulative histogram by dividing by the largest value and multiplying by the precision
			kernel3.setArg(0, cumulative_histogram);
			kernel3.setArg(1, look_up_table);
			kernel3.setArg(2, precision);
		}

		queue.enqueueNDRangeKernel(kernel3, cl::NullRange, cl::NDRange(L.size()), cl::NullRange, NULL, &prof_event);

		queue.enqueueReadBuffer(look_up_table, CL_TRUE, 0, size, &L.data()[0]);

		std::cout << "\nLook-Up Table:\n" << L << std::endl;

		currentExecution = prof_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - prof_event.getProfilingInfo<CL_PROFILING_COMMAND_START>(); //outputs execution time
		std::cout << "\nKernel execution time: \n" << currentExecution << std::endl;
		executionTime += currentExecution;

		//RE-PROJECTION

		vector<unsigned char> output_buffer(image_input.size());
		queue.enqueueWriteBuffer(dev_image_output, CL_TRUE, 0, output_buffer.size(), &output_buffer.data()[0]); //runs the original image through the look-up table to increase the intensity

		cl::Kernel kernel4;

		if (local == true) {
			kernel4 = cl::Kernel(program, "re_projection"); //runs input image through look-up table and outputs result
			kernel4.setArg(0, dev_image_input);
			kernel4.setArg(1, look_up_table);
			kernel4.setArg(2, dev_image_output);
			kernel4.setArg(3, cl::Local(size)); //local output image
			kernel4.setArg(4, precision);
		}
		else {
			kernel4 = cl::Kernel(program, "re_projection_global"); //runs input image through look-up table and outputs result
			kernel4.setArg(0, dev_image_input);
			kernel4.setArg(1, look_up_table);
			kernel4.setArg(2, dev_image_output);
			kernel4.setArg(3, precision);
		}

		queue.enqueueNDRangeKernel(kernel4, cl::NullRange, cl::NDRange(image_input.size()), cl::NullRange, NULL, &prof_event);

		queue.enqueueReadBuffer(dev_image_output, CL_TRUE, 0, output_buffer.size(), &output_buffer.data()[0]);

		std::cout << "\nBack-Projection:\nComplete." << std::endl;
		
		currentExecution = prof_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - prof_event.getProfilingInfo<CL_PROFILING_COMMAND_START>(); //outputs execution time
		std::cout << "\nKernel execution time: \n" << currentExecution << std::endl;
		executionTime += currentExecution;

		//runtime is typically around 9845500 global, and 3013400 local

		//Copy the result from device to host

		CImg<unsigned char> output_image(output_buffer.data(), image_input.width(), image_input.height(), image_input.depth(), image_input.spectrum());
		CImgDisplay disp_output(output_image, "output");

		std::cout << "\nTotal kernel execution time [ns]:" << executionTime << std::endl;
		std::cout << GetFullProfilingInfo(prof_event, ProfilingResolution::PROF_US) << endl;

 		while (!disp_input.is_closed() && !disp_output.is_closed() ////FIND A WAY TO STOP THE PROGRAM
			&& !disp_input.is_keyESC() && !disp_output.is_keyESC()) {
		    disp_input.wait(1);
		    disp_output.wait(1);
	    }
	}
	catch (const cl::Error& err) {
		std::cerr << "ERROR: " << err.what() << ", " << getErrorString(err.err()) << std::endl;
	}
	catch (CImgException& err) {
		std::cerr << "ERROR: " << err.what() << std::endl;
	}

	return 69; //lol
}