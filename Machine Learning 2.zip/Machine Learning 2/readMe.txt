This solution uses data from "dataset-nuclear_plants_final" to train an Artificial Neural Network
and a Random Forest. These will take a while to train but the results of the operations can be
seen at the end of the execution.