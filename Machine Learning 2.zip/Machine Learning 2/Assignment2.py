import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn.utils as sk
import sklearn.neural_network as nn
import sklearn.metrics as met
import sklearn.ensemble as en
from sklearn.model_selection import cross_val_score

filePath = "dataset-nuclear_plants_final.csv"
data = pd.read_csv(filePath) #reads the file contents to a numpy array
convert = {'Abnormal':0, 'Normal':1}
data = data.replace(convert) #replaces categorical variables with 1 and 0 for ease

def SummariseFeature(data): #used for the summarising of each feature in the csv file
    mean = np.mean(data) #mean
    std = np.std(data) #standard deviation
    mn = np.amin(data) #minimum value
    mx = np.amax(data) #maximum value
    return mean,std,mn,mx

def Summarise(data): #summarises the data as a whole
    sizeX = len(data.columns)
    sizeY = data.size / len(data.columns) #size of data
    sizeT = data.size
    feat = len(data.columns) #number of features
    null = data.isnull().values.any() #checks for missing values
    return sizeX,sizeY,sizeT,feat,null

def DataSplit(data,split): #used to split the data into sections
    data = sk.shuffle(data) #randomly sorts the dataframe's row order
    values = [] #initialises values list
    count = 0
    for i in split:
        values.append(data.iloc[count:i+count]) #splits the data by the number of items inputted
        count += i
    return(values)

for i in data.columns: #iterates through each column of data
    if (i != 'Status'): #excludes the categorical variable
        sf = SummariseFeature(data[i].astype(float)) #gets summary of each feature's data
        print(i , ":\n    Mean: " , sf[0], "\n    Standard Deviation: " , sf[1], "\n    Minimum: " , sf[2], "\n    Maximum: " , sf[3])
s = Summarise(data.astype(float)) #gets summary of data as a whole
print("General:\n    Size: " , int(s[0]), " by ", s[1],", ", s[2], " Total\n    Number of Features: " , s[3], "\n    Missing Values: " , s[4])

###boxplot###

box = data[['Status','Vibration_sensor_1']] #gathers data for plotting
box.boxplot(by='Status') #plots boxplot of vibration_sensor_1 against the status (1=normal, 0=abnormal)
plt.ylabel('Vibration_sensor_1')
plt.title('') #text was being written over other text, was easier to just assign the title to empty value
plt.show()

###density plot###

abnormal = data[data.Status.isin([0])] #sorts data between abnormal(0) and normal(1) status
normal = data[data.Status.isin([1])]
densityA = abnormal[['Vibration_sensor_2']] #grabs the vibration_sensor_2 data from each dataframe
densityN = normal[['Vibration_sensor_2']]
dat = pd.concat([densityA,densityN], axis = 1) #gathers data for plotting
dat.columns = ['Abnormal','Normal']
dat.plot.kde() #plots density plot of vibration_sensor_2
plt.xlabel('Vibration_sensor_2')
plt.title('Density Plot')
plt.show()

###artificial-neural-network###

total = data.size / len(data.columns)
split = [int(total*0.9),int(total*0.1)]
dataSplit = DataSplit(data,split) #splits data into 90% train and 10% test data
status = (dataSplit[0]['Status'],dataSplit[1]['Status'])
del dataSplit[0]['Status'] #removes categorical variable 'Status'
del dataSplit[1]['Status']

epochs = [250,500,750,1000,1500,2000,2500,5000,7500,10000]
accuracies = []

for i in epochs: #iterates through list of epochs
    mlp = nn.MLPClassifier(hidden_layer_sizes=(500, 500), max_iter=i, activation='logistic') #multi-layer perceptron is created with 2 hidden layers of 500-neurons each and logistic sigmoid activation function
    mlp.fit(dataSplit[0], status[0]) #inputs the training dataSplit
    predictions = mlp.predict(dataSplit[1]) #predictions for status are generated
    print(predictions)
    accuracy = met.accuracy_score(status[1],predictions) #predictions are weighed up against the actual test results to find how accurate the model is
    print(accuracy)
    accuracies.append(accuracy)

plt.plot(epochs,accuracies)
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.ylim(0,1)
plt.title('Number of Epochs against Accuracy')
plt.show()

###random-forest###

minSamp = [5,50]
trees = [10, 50, 100, 1000, 5000,10000]
accuracies = []
for i in minSamp:
    for j in trees:
        rf = en.RandomForestClassifier(n_estimators=j,min_samples_leaf=i) #creates random forest with varying numbers of trees and min-samples
        rf.fit(dataSplit[0], status[0]) #inputs the training dataSplit
        predictions = rf.predict(dataSplit[1]) #predictions for status are generated
        print(predictions)
        accuracy = met.accuracy_score(status[1],predictions) #predictions are weighed up against the actual test results to find how accurate the model is
        print(accuracy)
        accuracies.append(accuracy)
    
    plt.plot(trees,accuracies)
    plt.xlabel('Number of trees')
    plt.ylabel('Accuracy')
    plt.ylim(0,1)
    plt.title('Number of Trees against Accuracy')
    plt.show()
    accuracies = []

###cross-validation###

total = data.size / len(data.columns)
split = [int(total*0.9),int(total*0.1)]
data = DataSplit(data,split) #splits data into 90% train and 10% test data
status = (data[0]['Status'],data[1]['Status'])
del data[0]['Status'] #removes categorical variable 'Status'
del data[1]['Status']

scoresN = []
neurons = [50,500,1000]
print("ANN")
for i in neurons: #iterates through list of epochs
    mlp = nn.MLPClassifier(hidden_layer_sizes=(i,i), max_iter=10000, activation='logistic') #multi-layer perceptron is created with 2 hidden layers of 500-neurons each and logistic sigmoid activation function
    cvs = np.mean(cross_val_score(mlp,data[0],status[0],cv=10)) #finds cross-value scores for 10 fold, then finds the mean
    scoresN.append(cvs)
    print("  Mean Cross-Value Score for ",i," neurons in hidden layer:",cvs)

index = scoresN.index(max(scoresN))
print("The number of neurons with the highest CV Score is ",neurons[index])

scoresT = []
trees = [20,500,10000]
print("Random Forest")
for i in trees:
    rf = en.RandomForestClassifier(n_estimators=i,min_samples_leaf=5) #creates random forest with varying numbers of trees and min-samples
    cvs = np.mean(cross_val_score(rf,data[0],status[0],cv=10)) #finds cross-value scores for 10 fold, then finds the mean
    scoresT.append(cvs)
    print("  Mean Cross-Value Score for ",i," trees:",cvs) #passes in x and y training data and split size of 10

index = scoresT.index(max(scoresT))
print("The number of trees with the highest CV Score is ",trees[index])
