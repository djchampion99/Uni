Run Task1 for a demonstration of Polynomial Regression on a sample of data (pol_regression).

Run Task2 for a demonstration of K-Means Clustering on a collection of data (dog_breeds).