import numpy as np
import matplotlib.pyplot as plt

def Scatter(n,filename=None): #takes 2d array as a paramater, outputs scatter plot
    x = n[0] #breaks 2d array into 2 1d arrays
    y = n[1]
    #print(x) #used for testing
    #print(y)
    plt.figure()
    plt.scatter(x, y) #maps column 1 to x and column 2 to y in a scatter plot
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()
    
def Multi_Scatter(n,m,filename=None): #takes 2d array as a paramater, outputs scatter plot
    print(n)
    print(m)
    x1 = n[0] #breaks 2d array into 2 1d arrays
    y1 = n[1]
    x2 = m[0] #breaks 2d array into 2 1d arrays
    y2 = m[1]
    plt.figure()
    plt.scatter(x1, y1) #maps column 1 to x and column 2 to y in a scatter plot
    plt.scatter(x2, y2)
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()

def KMeans(cluster_assigned,k,filename=None):
    c = [] #initialises array
    for x in range(0,k):
        c.append(cluster_assigned[x])
    clusters = np.asarray(c)
    #print(clusters)
    plt.figure()
    for x in range(0,k):
        X = np.zeros(len(clusters[x]))
        Y = np.zeros(len(clusters[x]))
        for y in range(0,len(clusters[x])):
            X[y] = clusters[x][y][0]
            Y[y] = clusters[x][y][1]
        plt.scatter(X,Y)
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()

def Line(x,y,filename=None): #plots one axis against the other
    x = np.sort(x)
    y = np.sort(y)
    plt.figure()
    plt.plot(x,y)
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()

def Multi_Line(x1,y1,x2,y2,filename=None): #plots train data against test data, they should more or less line up
    plt.figure()
    plt.plot(x1,y2)
    plt.plot(x1,y2)
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()

def Regression(x,y,polynomial_array,filename=None):
    plt.figure()
    plt.plot(x,y, 'bo')
    for i in polynomial_array:
        plt.plot(x,i)
    plt.xlim((-5, 5))
    plt.legend(('training points', '$x^0$','$x$', '$x^2$', '$x^3$', '$x^5$', '$x^10$'), loc = 'lower right')
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()

def Eval(degrees,RMSE_train,RMSE_test,filename=None): #plots train data against test data, they should more or less line up
    plt.figure()
    plt.plot(degrees,RMSE_train)
    plt.plot(degrees,RMSE_test)
    plt.legend(('train RMSE', 'test RMSE'), loc = 'center right')
    if (filename != None): plt.savefig(filename + ".png") #if a filename is given, save the plot in png format to that filename
    plt.show()