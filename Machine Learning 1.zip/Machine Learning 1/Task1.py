import Reader
import Plot
import numpy as np
import math

data = Reader.ReadSort("pol_regression.csv") #imports data and splits it into sub-arrays
data = np.delete(data, 0, 0) #removes headers, making them all of one data type
data = data.astype(float) #converts from string to float
x = data[:,0]
y = data[:,1]
degrees = [0, 1, 2, 3, 5, 10] #array of all degrees that must be covered

def train_test_split(data): #used to split data into 70% training and 30% test
    size = int(data.size * 0.7)
    data = np.split(data,[size]) #splits data into 2 arrays
    train = data[0] #saves each array individually
    test = data[1]
    return train,test

def get_polynomial_weights(x, y, degree): #used to find the coefficient vector of the least squares hyperplane
    X = np.vander(x,degree+1,increasing=True)
    XX = X.transpose().dot(X)
    b = np.linalg.solve(XX, X.transpose().dot(y))
    return b

def pol_regression(features_train, y_train, degree): #returns y_test predictions
    b = get_polynomial_weights(features_train,y_train,degree)
    x = np.vander(features_train,degree+1,increasing=True)
    parameters = x.dot(b)
    return parameters

def eval_pol_regression(parameters, x, y, degrees):
    RMSEtrain = np.zeros((len(degrees),1))
    RMSEtest = np.zeros((len(degrees),1))
    X = train_test_split(x)
    Y = train_test_split(y)
    x_train = X[0]
    y_train = Y[0]
    x_test = X[1]
    y_test = Y[1]
    for i in range(0,len(degrees)):
        Xtrain = np.vander(x_train,degrees[i]+1,increasing=True)
        Xtest = np.vander(x_test,degrees[i]+1,increasing=True)
        
        w = get_polynomial_weights(x_train, y_train, degrees[i])  
        
        RMSEtrain[i] = math.sqrt(np.mean((Xtrain.dot(w) - y_train)**2)) #finds root mean square error
        RMSEtest[i] = math.sqrt(np.mean((Xtest.dot(w) - y_test)**2))
    return RMSEtrain,RMSEtest

#####ASSIGNMENT TASKS 1.2#####
'''
prediction_list = []

for i in degrees:
    n = pol_regression(x,y,i)
    prediction_list.append(n)
Plot.Regression(x,y,prediction_list,"regression")
'''
#####ASSIGNMENT TASKS 1.3#####

for i in degrees:
    parameters = pol_regression(x,y,i)
e = eval_pol_regression(parameters, x, y, degrees)
train = e[0]
test = e[1]
print(train)
print(test)

Plot.Eval(degrees,train,test,"evaluation")

###tests###

#get_polynomial_weights(x_train,y_train,4)

#Plot.Line(x,y)
#Plot.Multi_Line(x_train,y_train,x_test,y_test)