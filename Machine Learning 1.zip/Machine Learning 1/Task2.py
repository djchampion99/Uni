import Reader
import Plot
#import pandas as pd
import numpy as np
import random
import math

data = Reader.Read("dog_breeds.csv") #imports data
data = np.delete(data, 0, 0) #removes headers, making them all of one data type
data = data.astype(float) #converts from string to float
height = data[:,0] #splits data into sub-arrays
tail = data[:,1]
leg = data[:,2]
nose = data[:,3]

def compute_euclidean_distance(vec_1, vec_2): #finds distance between 2 points
    difference = np.subtract(vec_1, vec_2) #finds difference between the vectors by subtracting one from the other and finding the absolute value
    distance = math.sqrt(difference[0]**2 + difference[1]**2) #finds the hypotenuse using pythagorean theorem
    #print(distance) #used for testing
    return distance #returns euclidian distance

def initialise_centroids(dataset, k): #function used to initialise centroids
    centroids = np.zeros((k,2)) #creates an array to hold the co-ordinates of the centroids
    for i in range(0,k):
        r = random.randrange(dataset[0].size)
        a = dataset[0][r] #assigns a random value in the dataset as a centroid starting point
        b = dataset[1][r]
        centroids[i] = [a,b] #adds the points to the centroid array
    centroids = np.transpose(centroids) #transposes the matrix so it fits into other modules more easily
    return centroids

def assign_centroids(dataset, k, centroids):
    cluster_assigned = [] #initialises array
    for a in range(0,k):
        cluster_assigned.append([]) #adds a new list for each centroid
    for i in range(0,dataset[0].size):
        v1 = np.array([dataset[0][i], dataset[1][i]]) #selects value in array
        euclidian_distances = np.zeros(k) #initialiss array to hold all euclidian distances
        for j in range(0,k):
            v2 = np.array([centroids[0][j], centroids[1][j]]) #selects centroid
            #print(v1) #used for testing
            #print(v2)
            euclidian_distances[j] = compute_euclidean_distance(v1,v2) #finds distance between the centroid and the value
        #print(euclidian_distances) #used for testing
        #print(np.argmin(euclidian_distances))
        cluster_assigned[np.argmin(euclidian_distances)].append(v1) #adds value to the closest centroid
    cluster_assigned = np.asarray(cluster_assigned) #converts list to a numpy array
    return cluster_assigned #returns array of values, sorted between the number of clusters

def reassign_centroids(cluster_assigned,k):
    means = [] #initialises array
    for x in range(0,k):
        means.append(mean(cluster_assigned[x])) #finds means of each cluster
    means = np.asarray(means) #converts list to a numpy array
    means = np.transpose(means) #transposes the matrix so it fits into other modules more easily
    return means

def mean(dataset):
    totalX = 0.0 #initialises the totals
    totalY = 0.0
    for i in range(dataset[0].size):
        totalX += float(dataset[0][i]) #adds up all of the values
        totalY += float(dataset[1][i])
    totalX = totalX / dataset[0].size #divides by the number of items
    totalY = totalY / dataset[0].size
    return (totalX, totalY) #outputs mean co-ordinate

def sse(dataset, centroid): #used to find sum of squared errors
    total = 0
    for i in dataset:
        total += (compute_euclidean_distance(i,centroid))**2 #finds euclidian distance between each point and the centroid
    return total                                             #then squares it and adds it to the total

def kmeans(dataset, k, filename=None):
    SSEcount = []
    difference = 100 #initialises difference variable for later use
    centroids = initialise_centroids(dataset, k) #initialises centroids
    good_enough = 1
    while (difference > good_enough):
        cluster_assigned = assign_centroids(dataset, k, centroids) #assigns each value in the dataset to a centroid
        new_centroids = reassign_centroids(cluster_assigned,k)
        #print(new_centroids) #used for testing
        #print(centroids)
        diff_array = abs(np.subtract(new_centroids,centroids))
        difference = np.sum(diff_array)
        
        SSE = 0 #initialises sum of squared differences
        for i in range(0,k):
            SSE += sse(cluster_assigned[i],np.transpose(centroids)[i]) #finds total sse of each centroid
        #print(SSE) #used for testing
        SSEcount.append(SSE)
        
        centroids = new_centroids
        #print(cluster_assigned) #used for testing
    Plot.KMeans(cluster_assigned,k,filename) #plots the scatter graph
    #print(centroids) #used for testing
    return centroids, cluster_assigned, SSEcount

#####ASSIGNMENT TASKS 2.2#####

ht = np.vstack((height,tail)) #where x axis is “height” and y axis is “tail length”
kmeans(ht,2,"kmeans_ht_1")
kmeans(ht,3,"kmeans_ht_2")

hl = np.vstack((height,leg)) #where x axis is “height” and y axis is “leg length”
kmeans(hl,2,"kmeans_hl_1")
kmeans(hl,3,"kmeans_hl_2")

for k in range(2,4):
    n = np.vstack((height,tail))
    dat = kmeans(n,k)
    SSEcount = dat[2] #contains objective function (SSE)
    #print(SSEcount) #used for testing
    index = []
    for i in range(0,len(SSEcount)):
        index.append(i + 1) #contains iteration steps
    Plot.Line(index,SSEcount,"objective") #plots line graph of objective function

#c = np.vstack((height,tail))
#jeff = kmeans(c, 3)
#Plot.KMeans(jeff[1],3)

#print(jeff)

#Plot.Scatter(c)

#print(c[0][2])
#n = initialise_centroids(c,3)
#m = assign_centroids(c,3,n)
#kmeans(c,3)

#print(n)
#print(reassign_centroids(m,3))
#print(n[1][2])
#print(assign_centroids(c,3,n))
#print(initialise_centroids(c,3))
#a = np.array([2,2])
#b = np.array([3,3])
#print(compute_euclidean_distance(a,b))

#Plot.Scatter(c)
#Plot.Scatter(initialise_centroids(c,3))