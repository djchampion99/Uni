import pandas as pd
def Read(filePath): #takes filepath so the file can be located
    return(pd.read_csv(filePath, sep=',', header = None).to_numpy()) #returns the file contents to a numpy array
    
def ReadSort(filePath):
    n = pd.read_csv(filePath)
    n.sort_values('x',axis=0,inplace=True,na_position='last',ascending=True)
    n = n.to_numpy()
    return n

#data = ReadSort("pol_regression.csv") #used for testing
#print(data)